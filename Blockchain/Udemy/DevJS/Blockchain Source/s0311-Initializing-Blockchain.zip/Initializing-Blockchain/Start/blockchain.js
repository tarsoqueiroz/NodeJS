

class Blockchain {

  constructor(genesisBlock) {
    this.blocks = [] 
  }

}
