<style>

</style>

<div>
    <header>
        <div>
            <img src="" alt="">
        </div>
        <div>
            <h1>User Name</h1>
            <h2>Job Title</h2>
        </div>
    </header>
    <div>
        <p>A short description</p>
    </div>
</div>